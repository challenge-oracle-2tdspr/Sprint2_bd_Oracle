import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Scanner;


public class ProcedureDemo {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Iniciando. Pressione Enter para avançar em cada etapa.");
        try (Connection conn = DBConnection.getConnection()) {
            System.out.println("Conectado ao Oracle!\n");

            etapa1_insertUsers(conn);
            aguardarEnter("Etapa 1 completa — INSERTs de usuários. Pressione Enter para ir para UPDATEs de usuários...");

            etapa2_updateUsers(conn);
            aguardarEnter("Etapa 2 completa — UPDATEs de usuários. Pressione Enter para ir para DELETEs de usuários...");

            etapa3_deleteUsers(conn);
            aguardarEnter("Etapa 3 completa — DELETEs de usuários. Pressione Enter para INSERTs de propriedades...");

            etapa4_insertProperties(conn);
            aguardarEnter("Etapa 4 completa — INSERTs de propriedades. Pressione Enter para UPDATEs de propriedades...");

            etapa5_updateProperties(conn);
            aguardarEnter("Etapa 5 completa — UPDATEs de propriedades. Pressione Enter para DELETEs de propriedades...");

            etapa6_deleteProperties(conn);
            aguardarEnter("Etapa 6 completa — DELETEs de propriedades. Demo finalizada. Pressione Enter para sair.");

            System.out.println("Demo finalizada. Obrigado!");
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }

    // -------------------------------------------
    // Etapa 1: INSERT users (2 inserts)
    // -------------------------------------------
    private static void etapa1_insertUsers(Connection conn) {
        System.out.println("=== Etapa 1: INSERT users ===");
        try {
            try (CallableStatement stmt1 = conn.prepareCall("{ call sp_insert_user(?,?,?,?,?,?,?,?) }")) {
                stmt1.setString(1, "U001");
                stmt1.setString(2, "user1@test.com");
                stmt1.setString(3, "123");
                stmt1.setString(4, "123.456.789-00");
                stmt1.setString(5, "USER");
                stmt1.setString(6, "João");
                stmt1.setString(7, "Silva");
                stmt1.setString(8, "11988887777");
                stmt1.execute();
                System.out.println("INSERT user1 OK");
            }

            try (CallableStatement stmt2 = conn.prepareCall("{ call sp_insert_user(?,?,?,?,?,?,?,?) }")) {
                stmt2.setString(1, "U002");
                stmt2.setString(2, "user2@test.com");
                stmt2.setString(3, "456");
                stmt2.setString(4, "987.654.321-00");
                stmt2.setString(5, "ADMIN");
                stmt2.setString(6, "Maria");
                stmt2.setString(7, "Souza");
                stmt2.setString(8, "11999998888");
                stmt2.execute();
                System.out.println("INSERT user2 OK");
            }
        } catch (Exception e) {
            System.out.println("Erro na Etapa 1: " + e.getMessage());
        }
    }

    // -------------------------------------------
    // Etapa 2: UPDATE users (2 updates)
    // -------------------------------------------
    private static void etapa2_updateUsers(Connection conn) {
        System.out.println("=== Etapa 2: UPDATE users ===");
        try {
            try (CallableStatement stmt3 = conn.prepareCall("{ call sp_update_user(?,?,?,?,?,?,?,?) }")) {
                stmt3.setString(1, "U001");
                stmt3.setString(2, "joao_updated@test.com");
                stmt3.setString(3, "123");
                stmt3.setString(4, "123.456.789-00");
                stmt3.setString(5, "USER");
                stmt3.setString(6, "João Atualizado");
                stmt3.setString(7, "Silva");
                stmt3.setString(8, "11988887777");
                stmt3.execute();
                System.out.println("UPDATE user1 OK");
            }

            try (CallableStatement stmt4 = conn.prepareCall("{ call sp_update_user(?,?,?,?,?,?,?,?) }")) {
                stmt4.setString(1, "U002");
                stmt4.setString(2, "maria_updated@test.com");
                stmt4.setString(3, "999");
                stmt4.setString(4, "987.654.321-00");
                stmt4.setString(5, "ADMIN");
                stmt4.setString(6, "Maria Atualizada");
                stmt4.setString(7, "Souza");
                stmt4.setString(8, "11999998888");
                stmt4.execute();
                System.out.println("UPDATE user2 OK");
            }
        } catch (Exception e) {
            System.out.println("Erro na Etapa 2: " + e.getMessage());
        }
    }

    // -------------------------------------------
    // Etapa 3: DELETE users (2 deletes)
    // -------------------------------------------
    private static void etapa3_deleteUsers(Connection conn) {
        System.out.println("=== Etapa 3: DELETE users ===");
        try {
            try (CallableStatement stmt5 = conn.prepareCall("{ call sp_delete_user(?) }")) {
                stmt5.setString(1, "U001");
                stmt5.execute();
                System.out.println("DELETE user1 OK");
            }

            try (CallableStatement stmt6 = conn.prepareCall("{ call sp_delete_user(?) }")) {
                stmt6.setString(1, "U002");
                stmt6.execute();
                System.out.println("DELETE user2 OK");
            }
        } catch (Exception e) {
            System.out.println("Erro na Etapa 3: " + e.getMessage());
        }
    }

    // -------------------------------------------
    // Etapa 4: INSERT properties (2 inserts)
    // -------------------------------------------
    private static void etapa4_insertProperties(Connection conn) {
        System.out.println("=== Etapa 4: INSERT properties ===");
        try {
            try (CallableStatement p1 = conn.prepareCall("{ call sp_insert_property(?,?,?,?,?,?,?,?,?,?,?) }")) {
                p1.setString(1, "P001");
                p1.setString(2, "Fazenda Bela Vista");
                p1.setString(3, "Área agrícola completa");
                p1.setDouble(4, 100.5);
                p1.setString(5, "HECTARES");
                p1.setString(6, "Estrada Rural 10");
                p1.setString(7, "Campinas");
                p1.setString(8, "SP");
                p1.setString(9, "Brasil");
                p1.setString(10, "13000-000");
                p1.setString(11, null);
                p1.execute();
                System.out.println("INSERT property1 OK");
            }

            try (CallableStatement p2 = conn.prepareCall("{ call sp_insert_property(?,?,?,?,?,?,?,?,?,?,?) }")) {
                p2.setString(1, "P002");
                p2.setString(2, "Sítio Esperança");
                p2.setString(3, "Pequena plantação");
                p2.setDouble(4, 25.2);
                p2.setString(5, "HECTARES");
                p2.setString(6, "Estrada Rural 20");
                p2.setString(7, "Jundiaí");
                p2.setString(8, "SP");
                p2.setString(9, "Brasil");
                p2.setString(10, "13200-000");
                p2.setString(11, null);
                p2.execute();
                System.out.println("INSERT property2 OK");
            }
        } catch (Exception e) {
            System.out.println("Erro na Etapa 4: " + e.getMessage());
        }
    }

    // -------------------------------------------
    // Etapa 5: UPDATE properties (2 updates)
    // -------------------------------------------
    private static void etapa5_updateProperties(Connection conn) {
        System.out.println("=== Etapa 5: UPDATE properties ===");
        try {
            try (CallableStatement pu1 = conn.prepareCall("{ call sp_update_property(?,?,?,?,?,?,?,?,?,?,?) }")) {
                pu1.setString(1, "P001");
                pu1.setString(2, "Fazenda Bela Vista Atualizada");
                pu1.setString(3, "Área grande");
                pu1.setDouble(4, 120.0);
                pu1.setString(5, "HECTARES");
                pu1.setString(6, "Estrada Nova");
                pu1.setString(7, "Campinas");
                pu1.setString(8, "SP");
                pu1.setString(9, "Brasil");
                pu1.setString(10, "13000-000");
                pu1.setString(11, null);
                pu1.execute();
                System.out.println("UPDATE property1 OK");
            }

            try (CallableStatement pu2 = conn.prepareCall("{ call sp_update_property(?,?,?,?,?,?,?,?,?,?,?) }")) {
                pu2.setString(1, "P002");
                pu2.setString(2, "Sítio Esperança Atualizado");
                pu2.setString(3, "Plantação orgânica");
                pu2.setDouble(4, 30.0);
                pu2.setString(5, "HECTARES");
                pu2.setString(6, "Estrada Alterada");
                pu2.setString(7, "Jundiaí");
                pu2.setString(8, "SP");
                pu2.setString(9, "Brasil");
                pu2.setString(10, "13200-000");
                pu2.setString(11, null);
                pu2.execute();
                System.out.println("UPDATE property2 OK");
            }
        } catch (Exception e) {
            System.out.println("Erro na Etapa 5: " + e.getMessage());
        }
    }

    // -------------------------------------------
    // Etapa 6: DELETE properties (2 deletes)
    // -------------------------------------------
    private static void etapa6_deleteProperties(Connection conn) {
        System.out.println("=== Etapa 6: DELETE properties ===");
        try {
            try (CallableStatement pd1 = conn.prepareCall("{ call sp_delete_property(?) }")) {
                pd1.setString(1, "P001");
                pd1.execute();
                System.out.println("DELETE property1 OK");
            }

            try (CallableStatement pd2 = conn.prepareCall("{ call sp_delete_property(?) }")) {
                pd2.setString(1, "P002");
                pd2.execute();
                System.out.println("DELETE property2 OK");
            }
        } catch (Exception e) {
            System.out.println("Erro na Etapa 6: " + e.getMessage());
        }
    }

    // -------------------------------------------
    // Utilitário: aguarda Enter do usuário
    // -------------------------------------------
    private static void aguardarEnter(String mensagem) {
        System.out.println();
        System.out.println(mensagem);
        System.out.println("(Aperte Enter para continuar)");
        scanner.nextLine();
        System.out.println();
    }
}
