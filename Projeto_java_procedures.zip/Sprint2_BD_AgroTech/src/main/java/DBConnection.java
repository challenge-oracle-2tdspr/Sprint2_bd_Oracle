import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() throws Exception {

        String url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
        String user = "rm560209";
        String password = "100699"; // coloque sua senha

        return DriverManager.getConnection(url, user, password);
    }
}
